# basisprofil-de
Basisprofil DE

Hier werden die (Zwischen-) Ergebnisse der Basisprofile von HL7 Deutschland veröffentlicht.

Die Profile werden von der Projektgruppe Basisprofilierung des Technischen Komitees FHIR von HL7 Deutschland e.V. erstellt.

Die Diskussion der Profile findet auf Zulip statt. Implementierer und Interessenten sind herzlich eingeladen, sich an der Diskussion zu beteiligen, Fragen zu stellen, oder Feedback zu geben.

Die derzeit veröffentlichten Profile und Resourcen sind experimentell!

Eine formelle Abstimmung folgt.